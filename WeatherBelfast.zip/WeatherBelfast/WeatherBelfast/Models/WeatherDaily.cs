﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WeatherBelfast.Models
{
    public class WeatherDaily
    {
        [JsonProperty("id")]
        public string Id { get; set; }
        [JsonProperty("weather_state_name")]
        public string StateName { get; set; }
        [JsonProperty("weather_state_abbr")]
        public string StateAbrreviation { get; set; }
        [JsonProperty("wind_direction_compass")]
        public string WindDirectionCompass { get; set; }
        [JsonProperty("applicable_date")]
        public string ApplicableDate { get; set; }
        [JsonProperty("min_temp")]
        public string MinTemperature { get; set; }
        [JsonProperty("max_temp")]
        public string MaxTemperature { get; set; }
        [JsonProperty("the_temp")]
        public string CurrentTemperature { get; set; }
        [JsonProperty("wind_speed")]
        public string WindSpeed { get; set; }
        [JsonProperty("wind_direction")]
        public string WindDirection { get; set; }
        [JsonProperty("air_pressure")]
        public string AirPresssure { get; set; }
        [JsonProperty("humidity")]
        public string Humidity { get; set; }
        [JsonProperty("visibility")]
        public string Visibility { get; set; }
        [JsonProperty("predictability")]
        public string Predictability { get; set; }
    }

    public class RootObject
    {
        [JsonProperty("consolidated_weather")]
        public IEnumerable<WeatherDaily> ConsolidatedWeather { get; set; }
    }
}
