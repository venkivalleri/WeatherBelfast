﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WeatherBelfast.Repository;

namespace WeatherBelfast.Controllers
{
    public class HomeController : Controller
    {
        private readonly IWeatherRepository _weatherRepository;

        public HomeController(IWeatherRepository weatherRepository)
        {
            _weatherRepository = weatherRepository;
        }
        public IActionResult Index()
        {
            var result = _weatherRepository.GetConsolidatedWeather();
            return View(result);
        }
    }
}