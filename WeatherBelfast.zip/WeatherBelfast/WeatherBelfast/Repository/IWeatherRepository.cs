﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WeatherBelfast.Models;

namespace WeatherBelfast.Repository
{
    public interface IWeatherRepository
    {
        public IEnumerable<WeatherDaily> GetConsolidatedWeather();
    }
}
