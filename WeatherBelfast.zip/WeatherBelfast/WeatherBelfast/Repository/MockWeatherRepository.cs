﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WeatherBelfast.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace WeatherBelfast.Repository
{
    public class MockWeatherRepository : IWeatherRepository
    {
        public IEnumerable<WeatherDaily> GetConsolidatedWeather()
        {
            var consolidatedWeather = new List<WeatherDaily>();
            var  result = JsonConvert.DeserializeObject<RootObject>(File.ReadAllText(@"C:\Users\valleriv\Desktop\WeatherBelfast\WeatherBelfast\wwwroot\MockData\ConsolidatedWeather.json"));
            return result.ConsolidatedWeather;

        }
    }
}
