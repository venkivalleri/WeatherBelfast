﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using WeatherBelfast.Models;

namespace WeatherBelfast.Repository
{
    public class WeatherRepository : IWeatherRepository
    {
        public IEnumerable<WeatherDaily> GetConsolidatedWeather()
        {
             IEnumerable<WeatherDaily> weather=null;

            using (var client = new HttpClient())
            {

                //WebProxy proxy = new WebProxy("http://cloud-lb:8080", true);
                //proxy.UseDefaultCredentials = true;
                //WebRequest.DefaultWebProxy = proxy;

                client.BaseAddress = new Uri("https://www.metaweather.com");
                //HTTP GET
                var responseTask = client.GetAsync("/api/location/44544/");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var _consolidatedWeather = readTask.Result;

                    RootObject root = JsonConvert.DeserializeObject<RootObject>(_consolidatedWeather);

                    weather = root.ConsolidatedWeather.Take(5);

                }
            }

            return weather;
        }
    }
}
