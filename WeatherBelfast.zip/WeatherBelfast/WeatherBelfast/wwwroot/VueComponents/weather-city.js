﻿Vue.component("weather-city", {
    props: ['weatherdata'],
    data: function () {
    return {
		dateTime: null,
     };
    },
    //created: function () {
    //    $.get("MockData/ConsolidatedWeather.json", response => {
    //        this.weatherdata = response;
    //    });
    //},
        created: function () {
            this.dateTime = new Date();
    },
    methods: {

        getImageType(abbr) {
            
            return "https://www.metaweather.com/static/img/weather/png/"+abbr+".png";
		},

		getDecimalPlaces(number) {
			var _number = parseInt(number);
			return _number.toFixed(0);
		},

		getDateToDay(date) {
			var date = new Date(date);
			weekday = new Array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
			today = this.dateTime.getDay();
			var day = "";
			if (today === date.getDay()) {
				day = "Today"
			}
			else if (today + 1 === date.getDay()) {
				day = "Tomorrow"
			}
			else {
				day = weekday[date.getDay()];
			}
			return day;
		}
    },
    template: `
<div class="row weather weather-sml">
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
		<h2>
			<p><strong>Belfast</strong></p>
		</h2>
		<p>
			Updated {{dateTime.toString()}}<br>
		</p>
	</div>
<div v-for="weather in weatherdata">
<div class="col-lg-2 col-md-2 col-sm-2 col-xs-4">
			<h3>
                <img class="state-icon-sml"  v-bind:src="getImageType(weather.stateAbrreviation)">
				<span><strong>{{getDateToDay(weather.applicableDate)}}</strong></span>
			</h3>
				<dl>
					<dt>Weather</dt>
					<dd class="weatherstate" data-original-title="" title="">
                        <span>{{weather.stateName}}</span>

					</dd>
					<dt>Temperature</dt>
					<dd>
							Max: {{getDecimalPlaces(weather.maxTemperature)}}°C<br>
							Min: {{getDecimalPlaces(weather.minTemperature)}}°C			
					</dd>
					<dt>Wind</dt>
					<dd class="wind">
						Wind: {{getDecimalPlaces(weather.windSpeed)}}mph
					</dd>
					<dd class="wind">
						Humidity: {{weather.humidity}}%
					</dd>
					<dd class="wind">
						Visibility: {{getDecimalPlaces(weather.visibility)}} miles
					</dd>
					<dd class="wind">
						Pressure: {{getDecimalPlaces(weather.airPresssure)}}mb
					</dd>
				</dl>

</div>
</div>
</div>

        `

});