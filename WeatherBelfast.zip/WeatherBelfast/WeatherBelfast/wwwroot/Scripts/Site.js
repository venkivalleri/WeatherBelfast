﻿new Vue({
    el: "#app",
    data: {
        Comments: 'Vue here'
    }
});